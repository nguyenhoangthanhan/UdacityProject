package com.udacity.shoestore.utils

object Constants {

    public val EMAIL_EXIST_DEMO:String = "abc@gmail.com"

    public val PASSWORD_EXIST_DEMO:String = "abc123"
}