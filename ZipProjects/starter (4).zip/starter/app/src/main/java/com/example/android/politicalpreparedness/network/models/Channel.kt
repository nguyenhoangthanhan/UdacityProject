package com.example.android.politicalpreparedness.network.models

data class Channel (
    val type: String,
    val id: String
)